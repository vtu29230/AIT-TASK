/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Task 1: digitSum opt (sum of even or odd digits)
public class Main {

    public static int EvenOddDigitsSum(int input1, String input2) {
        int sum = 0;

        while (input1 > 0) {
            int digit = input1 % 10;

            if ("even".equalsIgnoreCase(input2) && digit % 2 == 0) {
                sum += digit;
            } else if ("odd".equalsIgnoreCase(input2) && digit % 2 != 0) {
                sum += digit;
            }

            input1 /= 10;
        }

        return sum;
    }

    public static void main(String[] args) {
        System.out.println(EvenOddDigitsSum(123456, "even")); // 12
        System.out.println(EvenOddDigitsSum(123456, "odd"));  // 9
    }
}